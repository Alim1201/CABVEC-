# CABVEC — prototype de départ

Ce projet fournit une première interface web responsive : catalogue public, lien WhatsApp et écran de connexion administrateur. **Ce n'est pas encore une APK installable ni une application prête pour une utilisation réelle.**

## Connecter Supabase
1. Ouvrez `CABVEC-TEST` dans Supabase.
2. Allez dans **Project Settings → API**.
3. Copiez l'URL du projet et la clé publique `anon`/publishable.
4. Copiez `.env.example` vers `.env.local` et remplacez les valeurs d'exemple.

Ne partagez jamais votre mot de passe de base de données ni la clé `service_role`/secret. N'intégrez jamais cette clé secrète au navigateur ou à une APK.

## Tester (sur ordinateur avec Node.js)
`npm install`
`npm run dev`

## À faire avant la production
- définir et vérifier les rôles administrateur côté serveur ;
- écrire et tester les politiques RLS ;
- ajouter une fonction serveur sécurisée pour créer les commandes et valider prix/stocks ;
- développer la gestion des produits, stocks, ventes, lots et dates de péremption ;
- intégrer les paiements seulement après choix et validation du prestataire ;
- tester puis emballer l'interface avec Capacitor et compiler l'APK Android.

Le projet Supabase actuel permet la lecture publique des produits actifs uniquement. Les écritures et commandes ne sont pas encore activées, volontairement, tant que les protections ne sont pas configurées.
